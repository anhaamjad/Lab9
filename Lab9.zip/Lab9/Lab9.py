INF = 999999   
def minimax(node, is_max):          
    if isinstance(node, int):       
        return node                 
    if is_max:                      
        best = -INF                 
        for child in node:          
            best = max(best, minimax(child, False))  
        return best                 
    else:                           
        best = INF                  
        for child in node:          
            best = min(best, minimax(child, True))   
        return best                 
def alphabeta(node, is_max, alpha, beta):  
    if isinstance(node, int):       
        return node                 
    if is_max:                      
        best = -INF                
        for child in node:          
            value = alphabeta(child, False, alpha, beta)  
            best = max(best, value) 
            alpha = max(alpha, best)
            if beta <= alpha:       
                break               
        return best                 
    else:                           
        best = INF                 
        for child in node:          
            value = alphabeta(child, True, alpha, beta)   
            best = min(best, value) 
            beta = min(beta, best)  
            if beta <= alpha:       
                break               
        return best                 
tree1 = [[[3, 5], [6, 9]], [[1, 2], [0, -1]]]   
print("Tree 1 Minimax    :", minimax(tree1, True))                
print("Tree 1 Alpha-Beta :", alphabeta(tree1, True, -INF, INF))  
tree2 = [[[-1, 4], [2, 6]], [[-3, -5], [0, 7]]]  
print("Tree 2 Minimax    :", minimax(tree2, True))
print("Tree 2 Alpha-Beta :", alphabeta(tree2, True, -INF, INF))